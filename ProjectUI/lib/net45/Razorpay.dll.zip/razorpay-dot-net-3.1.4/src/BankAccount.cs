using System.Collections.Generic;

namespace Razorpay.Api
{
    public class BankAccount : Entity
    {

    }
}