namespace Razorpay.Api
{
    public class Reversal : Entity
    {
        
    }
}