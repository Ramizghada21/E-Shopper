﻿using System;

namespace Razorpay.Api
{
    public enum HttpMethod
    {
        GET,
        POST,
        DELETE,
        PUT,
        PATCH,
    }
}
